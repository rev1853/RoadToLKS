package com.example.esemkashowroom

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.widget.AppCompatButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.net.URL

class updateData : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_data)

        findViewById<AppCompatButton>(R.id.u_update).setOnClickListener {
            GlobalScope.launch(Dispatchers.IO){
                val url = URL("https://6597231a668d248edf22a0d3.mockapi.io/Cars")

            }
        }
    }
}