package com.example.esemkashowroom

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.AppCompatButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class detailData : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_data)

                val data = JSONObject(intent.getStringExtra("id"))

                val nama = findViewById<TextView>(R.id.d_nama)
                nama.text = data.getString("name")
                val model = findViewById<TextView>(R.id.d_model)
                model.text = data.getString("model")
                val brand = findViewById<TextView>(R.id.d_brand)
                brand.text = data.getString("brand")
                val year = findViewById<TextView>(R.id.d_tahun)
                year.text = data.getString("year")
                val update = findViewById<AppCompatButton>(R.id.update)
                update.setOnClickListener {

                   // val r = editText2.text.toString()
                    val intent = Intent(this, updateData::class.java)
                    intent.putExtra("updateData",data.toString())
                    startActivity(intent)
                }




        val delete = findViewById<Button>(R.id.d_delete)
        delete.setOnClickListener {
            GlobalScope.launch(Dispatchers.IO) {
                val url = URL("https://6597231a668d248edf22a0d3.mockapi.io/Cars/${data}")
                    val conn = url.openConnection() as HttpURLConnection
                    conn.requestMethod = "DELETE"
                    conn.doOutput =true
                    val code = conn.responseCode
                    code == HttpURLConnection.HTTP_OK



                GlobalScope.launch(Dispatchers.Main) {

                    if (code == 404) {
                        Toast.makeText(this@detailData, "Data cannot be deleted", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@detailData, "Successful deleting data", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                }
            }







        }
    }
}